#include "Pythia8/Pythia.h"
using namespace Pythia8;

int main(){
  Pythia pythia;
  pythia.particleData.list();
}
