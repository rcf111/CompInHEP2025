After installing LHAPDF, remember to copy the PDF's you want to use under
$LHAPATH (here $PWD/LHAPDF)

export LHAPATH=$PWD/LHAPDF
cd $LHAPATH && wget http://lhapdfsets.web.cern.ch/lhapdfsets/current/cteq6l1.tar.gz && tar xfvz cteq6l1.tar.gz

If you want to test LHAPDF5, change two relevant lines in the Makefile
the LHAPDF_URL and pythia8 ./configure --with-lhapdf5=...
