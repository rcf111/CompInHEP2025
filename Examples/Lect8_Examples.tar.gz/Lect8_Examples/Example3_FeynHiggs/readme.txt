wget http://wwwth.mpp.mpg.de/members/heinemey/feynhiggs/newversion/FeynHiggs-2.19.0.tar.gz --no-check-certificate
tar xfvz FeynHiggs-2.19.0.tar.gz
cd FeynHiggs-2.19.0
sed -i '/CFLAGS-/ s/-Wall/-Wall -fPIE/' configure
./configure
make
cd example
gfortran demo.cc -I../build -L../build/ -lFH -lstdc++ -o demo.exe

***

modified demo.cc for printing out the xsec. Looking the API guide in feynhiggs.de, the function returning the xsec is
FHHiggsProd. In the docs a Fortran version is given, must be transformed into c++ in the demo.cc.

Synopsis – Fortran version
#include "FHCouplings.h"
integer error
double precision sqrts, prodxs(nprodxs)
subroutine FHHiggsProd(error, sqrts, prodxs)


gfortran demo.cc -IFeynHiggs-2.19.0/build -LFeynHiggs-2.19.0/build/ -lFH -lstdc++ -o demo.exe
