wget http://tiger.web.psi.ch/hdecay/hdecay.tar.gz
tar xfvz hdecay.tar.gz
make
run
