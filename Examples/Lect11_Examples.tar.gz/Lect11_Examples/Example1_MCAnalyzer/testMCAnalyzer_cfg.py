import FWCore.ParameterSet.Config as cms

process = cms.Process("test")

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(-1)
)

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(
        "file:H200ZZ4L_13TeV_TuneCUETP8M1_cfi_py_GEN.root"
    )
)

process.analysis = cms.EDAnalyzer('TestMCAnalyzer',
#	src = cms.InputTag("generatorSmeared")
	src = cms.InputTag("genParticles")
)

# module execution
process.runEDAna = cms.Path(process.analysis)

