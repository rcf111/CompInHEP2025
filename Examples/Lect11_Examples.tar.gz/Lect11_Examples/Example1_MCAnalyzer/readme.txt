scram p CMSSW CMSSW_14_0_4
cd CMSSW_14_0_4/src
cmsenv
git cms-addpkg Configuration/Generator

edit the bug in the gen fragment Configuration/Generator/python/H200ZZ4L_13TeV_TuneCUETP8M1_cfi.py (hase ->Phase)

scram b -j 16

# Event generator (GEN)
cmsDriver.py Configuration/Generator/python/H200ZZ4L_13TeV_TuneCUETP8M1_cfi.py --eventcontent RAWSIM --datatier GEN-SIM --conditions auto:run3_mc_GRun --step GEN --no_exec
cmsRun H200ZZ4L_13TeV_TuneCUETP8M1_cfi_py_GEN.py

# Event generator (GEN) +  Geant4 (SIM)
cmsDriver.py Configuration/Generator/python/H200ZZ4L_13TeV_TuneCUETP8M1_cfi.py --eventcontent RAWSIM --datatier GEN-SIM --conditions auto:run3_mc_GRun --step GEN,SIM --era Run3_2023 --no_exec
cmsRun H200ZZ4L_13TeV_TuneCUETP8M1_cfi_py_GEN_SIM.py

# analysis (in dir CMSSW_X_Y_Z/src)
mkdir -p TestAnalyzers/Analysis/test
cp ../../TestMCAnalyzer.cpp ../../testMCAnalyzer_cfg.py ../../BuildFile.xml TestAnalyzers/Analysis/test
cd TestAnalyzers/Analysis/test
scram b -j 16

edit testMCAnalyzer_cfg.py to use the generated root file as input
cmsRun testMCAnalyzer_cfg.py

