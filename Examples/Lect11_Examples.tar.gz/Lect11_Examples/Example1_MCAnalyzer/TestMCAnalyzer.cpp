#include "FWCore/MessageLogger/interface/MessageLogger.h"
#include "FWCore/Framework/interface/one/EDAnalyzer.h"

#include "FWCore/Framework/interface/EventSetup.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"

#include "FWCore/Framework/interface/Event.h"

#include "SimDataFormats/GeneratorProducts/interface/HepMCProduct.h"
#include "DataFormats/HepMCCandidate/interface/GenParticle.h"
#include "DataFormats/JetReco/interface/GenJet.h"

//using namespace HepMC;
using namespace edm;

#include <iostream>
using namespace std;

class TestMCAnalyzer : public edm::one::EDAnalyzer<> {
    public:
	TestMCAnalyzer(const edm::ParameterSet&);
	~TestMCAnalyzer();

	void beginJob();
	void analyze( const edm::Event&, const edm::EventSetup&);
	void endJob();

    private:
        edm::EDGetTokenT<reco::GenParticleCollection> srcToken;
};

TestMCAnalyzer::TestMCAnalyzer(const edm::ParameterSet& iConfig) :
  srcToken(consumes<reco::GenParticleCollection>(iConfig.getParameter<edm::InputTag>("src")))
{}

TestMCAnalyzer::~TestMCAnalyzer() {}

void TestMCAnalyzer::beginJob(){}
void TestMCAnalyzer::analyze( const edm::Event& iEvent, const edm::EventSetup& iSetup){

        Handle<reco::GenParticleCollection> genParticleHandle;
        try{
          iEvent.getByToken(srcToken,genParticleHandle);
        }catch(...) {;}
        
        if(genParticleHandle.isValid()){

                cout << "GenParticles size " << genParticleHandle->size() << endl;

        	for(size_t i=0; i<genParticleHandle->size(); ++i) {
                       const reco::Candidate & gp = genParticleHandle->at(i); 
                       const reco::Candidate* mom = gp.mother();
                       int momId = 0;
                       if(mom) momId = mom->pdgId();
                       cout << "  particle " 
                             << " " << gp.pdgId()
                             << " " << momId
                             << " " << gp.status()
                             << " " << gp.pt()
                             << " " << gp.eta()
                             << " " << gp.phi()
                             << endl;
		}
	}
}
void TestMCAnalyzer::endJob(){}

DEFINE_FWK_MODULE(TestMCAnalyzer);
