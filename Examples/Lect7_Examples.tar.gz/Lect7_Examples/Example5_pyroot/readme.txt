graph.py doesnt work, the arrays are 
x = []
y = []

in graph_v2.py these arrays are converted to array.arrays

    xarr = array("d",x)
    yarr = array("d",y)

and the script works.
