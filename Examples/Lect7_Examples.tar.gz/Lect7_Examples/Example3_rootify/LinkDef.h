#include "Track.h"
#include "Event.h"

#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class Track+;
#pragma link C++ class std::vector<Track>;
#pragma link C++ class Event+;

#endif
