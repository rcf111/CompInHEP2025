make
make test
test.job

To be able to browse the Event content stored in the root file,
root analysis.root

#gSystem->Load("$ROOTSYS/lib/libPhysics.so")
gSystem->Load("libEvent.so")
new TBrowser
