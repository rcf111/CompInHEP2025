Original rootfile with all events: histograms-QCD_HT50to100.root
Check the run:lumi:event numbers:  runLumiEvent.py histograms-QCD_HT50to100.root
Events to be picked:               pickevents.txt
Run picking: 			   pickEvents.py histograms-QCD_HT50to100.root -pick pickevents.txt
Check the run:lumi:event numbers:  runLumiEvent.py picked_histograms-QCD_HT50to100.root

