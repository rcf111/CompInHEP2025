#include "interface.cc"

int main(){

  FortranInterface("Hello world!");

}
