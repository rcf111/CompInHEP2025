#!/usr/bin/env python

import sys
import os

home = os.environ['HOME']
mypythonpath = os.path.join(home,"python/lib/python")
sys.path.append(mypythonpath)

import MyModule

MyModule.my_test("Hello World!")
