#!/bin/sh

export ROOTSYS=.
ls /cvmfs/cms.cern.ch/
export LD_LIBRARY_PATH=${ROOTSYS}/libs:/cvmfs/cms.cern.ch/slc7_amd64_gcc900/external/gcc/9.3.0/lib64:/usr/lib64

tar xfvz libs.tar.gz
tar xfvz etc.tar.gz
#chmod +x ./writing
./writing
