Since one cannot be sure that ROOT is installed in the CE the job is sent, all the needed libs must
be sent there, too. ROOT needs stuff also from the ROOT etc directory. Together this means sending
quite a number of files to the CE, and it's most conveniently done by making a tarball of them. The
job script must unpack the tarball, set LD_LIBRARY_PATH to point to the libs and run the program.

maketarball.py

you can check all used libs with
ldd writing

You need also the etc-dir:
cp -r $ROOTSYS/etc .
tar cfv etc.tar etc
gzip etc.tar

arcproxy -S <your-VO>

arcsub -c kale-cms.grid.helsinki.fi test.xrsl
