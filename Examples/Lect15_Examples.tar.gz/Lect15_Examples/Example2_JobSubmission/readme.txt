Assuming .globus is ok..

arcproxy -S <your-VO>

# xrsl job description language
arcsub -C alcyone-cms.grid.helsinki.fi test.xrsl
arcstat https://alcyone-cms.grid.helsinki.fi:443/arex/rest/1.0/jobs/77c911367716
arcget https://alcyone-cms.grid.helsinki.fi:443/arex/rest/1.0/jobs/77c911367716

arcsub -C kale-cms.grid.helsinki.fi test.xrsl
arcstat https://kale-cms.grid.helsinki.fi:443/arex/rest/1.0/jobs/...
arcget https://kale-cms.grid.helsinki.fi:443/arex/rest/1.0/jobs/...

