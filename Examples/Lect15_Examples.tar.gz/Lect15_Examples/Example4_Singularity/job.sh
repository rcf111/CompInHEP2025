#!/usr/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/lib/x86_64-linux-gnu:/opt/conda/lib:/usr/lib/:/usr/local/lib

cd /work
./writing
