export G4INSTALL=$PWD/geant4

export G4SYSTEM=Linux-g++

export G4LEDATA=${G4INSTALL}/share/Geant4/data/G4EMLOW8.6.1
export G4LEVELGAMMADATA=${G4INSTALL}/share/Geant4/data/PhotonEvaporation6.1
export G4SAIDXSDATA=${G4INSTALL}/share/Geant4/data/G4SAIDDATA2.0
export G4LIB=${G4INSTALL}/lib
export G4ENSDFSTATEDATA=${G4INSTALL}/share/Geant4/data/G4ENSDFSTATE3.0
export G4PARTICLEXSDATA=${G4INSTALL}/share/Geant4/data/G4PARTICLEXS4.1


export PATH=${PATH}:${HOME}/public/Programs/dawn_3_91a
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${G4INSTALL}/lib
