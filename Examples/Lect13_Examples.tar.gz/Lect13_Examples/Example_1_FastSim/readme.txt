# Example 1

scram p CMSSW CMSSW_14_0_4
cd CMSSW_14_0_4/src
cmsenv
git cms-addpkg Configuration/Generator
scram b -j 8

# Beamspots in Configuration/StandardSequences/python/VtxSmeared.py

cmsDriver.py Configuration/Generator/python/TTbar_13TeV_TuneCUETP8M1_cfi.py -s GEN,SIM,RECOBEFMIX,DIGI:pdigi_valid,L1,DIGI2RAW,L1Reco,RECO -n 10 --conditions auto:run2_mc --datatier AODSIM --eventcontent AODSIM --fast --era Run2_2016 --no_exec

cmsRun TTbar_13TeV_TuneCUETP8M1_cfi_py_GEN_SIM_RECOBEFMIX_DIGI_L1_DIGI2RAW_L1Reco_RECO.py
