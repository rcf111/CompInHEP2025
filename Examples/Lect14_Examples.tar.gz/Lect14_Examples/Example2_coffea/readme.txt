# Virtual environment
python -m venv VirtualTestEnvironment
source VirtualTestEnvironment/bin/activate
pip install coffea

analysis_coffea.py
