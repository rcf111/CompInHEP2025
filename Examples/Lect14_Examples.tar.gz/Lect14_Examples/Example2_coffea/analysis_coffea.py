#!/usr/bin/env python

import sys
import os,re
import datetime

import hist
import dask
import awkward as ak
import hist.dask as hda
import dask_awkward as dak

from coffea import nanoevents
from coffea.nanoevents import NanoEventsFactory, NanoAODSchema
from coffea import processor
from coffea.nanoevents.methods import candidate, vector


import hist
import uproot

class Analysis(processor.ProcessorABC):
    def __init__(self):
        self.histograms = {}
        self.histograms["h_mass"] = (
            hda.Hist.new
            .Reg(200, 0 ,200, name="x", label="x-axis")
            .Double()
        ) 

    def process(self, events):

        muons = ak.zip(
            {
                "pt": events.Muon.pt,
                "eta": events.Muon.eta,
                "phi": events.Muon.phi,
                "mass": events.Muon.mass,
                "charge": events.Muon.charge,
            },
            with_name="PtEtaPhiMCandidate",
            behavior=candidate.behavior,
        )

        cut = (ak.num(muons) == 2) & (ak.sum(muons.charge, axis=1) == 0)
        # add first and second muon in every event together
        dimuon = muons[cut][:, 0] + muons[cut][:, 1]

        self.histograms["h_mass"].fill(x=dimuon.mass)

        out = {}
        out.update(self.histograms)
        return out

    def postprocess(self, accumulator):
        pass

def main():
    filename = "file://DYJetsToLL_M_50_2022.root"
    events = NanoEventsFactory.from_root(
        {filename: "Events"},
        metadata={"dataset": "DoubleMuon"},
        schemaclass=NanoAODSchema,
    ).events()
    p = Analysis()
    out = p.process(events)
    (result,) = dask.compute(out)

    with uproot.recreate("output.root") as fOUT:
        days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        now = datetime.datetime.now()
        m = "produced: %s %s"%(days[now.weekday()],now)
        fOUT[f"{m}"] = ""

        for key in result.keys():
            fOUT[f"{key}"] = result[key]


if __name__ == "__main__":
    main()
