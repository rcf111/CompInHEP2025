#!/usr/bin/sh

cd /work
python analysis_coffea.py


