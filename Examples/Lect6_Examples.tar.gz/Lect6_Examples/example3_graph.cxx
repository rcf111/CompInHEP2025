#define N 3
void example3_graph(){

  TH2F *frame = new TH2F("frame","",2,0,5,2,0,5);
  frame->Draw();
  
  //  int N = 3;
  float x[3] = {1,2,3};
  float y[3] = {2,3,4};

  TGraph* myGraph = new TGraph(N,x,y);
  myGraph->Draw("same");

  float x2[3] = {2,3,4};
  float y2[3] = {2,3,3};

  TGraph* myGraph2 = new TGraph(N,x2,y2);
  myGraph2->SetLineColor(2);
  myGraph2->SetLineWidth(2);
  myGraph2->Draw("same");
}
