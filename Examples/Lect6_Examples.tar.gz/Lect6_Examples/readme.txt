Execute by typing
root <script file>
