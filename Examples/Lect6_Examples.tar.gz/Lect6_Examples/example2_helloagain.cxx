void example2_helloagain(){
  cout << "Hello again!" << endl;
  exit(0);
}
